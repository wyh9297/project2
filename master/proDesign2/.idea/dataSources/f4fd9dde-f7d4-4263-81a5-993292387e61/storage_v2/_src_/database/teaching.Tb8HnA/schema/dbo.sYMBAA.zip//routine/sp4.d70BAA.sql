create procedure SP4 @grade int
as
SELECT sc.cno,cname
FROM student_course sc,course c
WHERE sc.cno=c.cno
group by sc.cno,cname having avg(grade)>=@grade
go

