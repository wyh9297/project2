create procedure SP3
as
SELECT s.sno,sname,spec,sex 
FROM student s,student_course sc
WHERE s.sno=sc.sno
group by s.sno,sname,spec,sex having COUNT(*)>=2
go

