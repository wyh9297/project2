create procedure SP1
as
SELECT sc.cno as 课程号,cname as 课程名,avg(grade) as 平均成绩,MAX(grade) as 最高分,min(grade) as 最低分 
FROM student s,student_course sc,course c
WHERE s.sno=sc.sno and sc.cno=c.cno and spec='计算机'
group by sc.cno,cname
go

