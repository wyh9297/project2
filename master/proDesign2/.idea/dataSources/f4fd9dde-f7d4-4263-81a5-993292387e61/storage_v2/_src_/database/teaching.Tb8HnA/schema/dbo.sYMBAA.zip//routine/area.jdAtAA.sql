create  function  AREA(@R  float)
returns  float
as   begin
           set @R=3.1415926*@R*@R
           return @R
       end
go

