
create view V4
as select *
from student
where scholarship>0
go

