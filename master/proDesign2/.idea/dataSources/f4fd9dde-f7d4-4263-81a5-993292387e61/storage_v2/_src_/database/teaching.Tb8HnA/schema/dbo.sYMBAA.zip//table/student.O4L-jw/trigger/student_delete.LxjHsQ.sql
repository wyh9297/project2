CREATE TRIGGER  student_delete 
ON dbo.student FOR  DELETE 
AS 
    delete from student_course
    where sno in
             (select sno from deleted)
go

