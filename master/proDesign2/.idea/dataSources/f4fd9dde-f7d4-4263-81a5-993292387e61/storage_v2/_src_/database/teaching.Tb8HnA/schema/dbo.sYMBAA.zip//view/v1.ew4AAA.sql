create view V1(sno,sname,avg_grade)
as select student.sno,sname,avg(grade)
from student_course,student
where student.sno=student_course.sno
group by student.sno,sname
go

