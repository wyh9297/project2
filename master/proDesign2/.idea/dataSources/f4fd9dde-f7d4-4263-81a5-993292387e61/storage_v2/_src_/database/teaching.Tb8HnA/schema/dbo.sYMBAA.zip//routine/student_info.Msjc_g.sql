CREATE PROCEDURE student_info @student_name varchar(20) 
AS select sno,sname,email
      from student
      where sname=@student_name
go

