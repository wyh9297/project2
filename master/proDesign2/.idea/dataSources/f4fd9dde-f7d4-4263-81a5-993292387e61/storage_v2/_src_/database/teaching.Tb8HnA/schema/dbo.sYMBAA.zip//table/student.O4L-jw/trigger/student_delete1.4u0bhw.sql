CREATE TRIGGER  student_delete1 
ON dbo.student 
AFTER  DELETE 
AS 
          DELETE FROM student_course
          WHERE sno in
             (select sno from deleted)
go

