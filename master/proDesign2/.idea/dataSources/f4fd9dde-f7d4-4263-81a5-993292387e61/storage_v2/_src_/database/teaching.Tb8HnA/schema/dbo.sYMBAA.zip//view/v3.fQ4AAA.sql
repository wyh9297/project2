create view V3(sno,sname,spec)
as select distinct student.sno,sname,spec
from student,student_course
where student.sno=student_course.sno and
not exists
(select * from student_course where sno=student.sno and grade<80)
go

