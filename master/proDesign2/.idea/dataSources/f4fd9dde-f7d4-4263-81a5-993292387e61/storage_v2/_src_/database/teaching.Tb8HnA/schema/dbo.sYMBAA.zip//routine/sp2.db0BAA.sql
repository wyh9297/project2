create procedure SP2
as
SELECT spec as 专业名称,COUNT(*) as 专业人数 
FROM student
group by spec
order by 专业人数 desc
go

