create view V6
as select  c.*,sc.grade,s.*
from course c,student_course sc,student s
where c.cno=sc.cno and s.sno=sc.sno
go

