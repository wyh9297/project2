create view V5(cno,cname,credit)
as select distinct course.cno,cname,credit
from course,student_course
where course.cno=student_course.cno and grade=100
go

